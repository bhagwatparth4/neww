RUSH HOURS APP - DEPLOYMENT BUNDLE
=================================

Contents
- qrCode-main/: React frontend + Spring Boot backend source
- deploy-ec2.sh: Ubuntu deployment script (installs Java 21, Node 20, Docker, Nginx; builds app; sets up Postgres/Redis and systemd)
- cafeqr.secrets.env.example: safe template only; no real secrets are included

IMPORTANT SECURITY NOTE
The original uploaded archive contained real-looking database, payment, JWT, SMS and Web Push credentials. They were intentionally not copied into this bundle. If those values were used on a live service, rotate them before deploying. Do not put real credentials in the frontend .env files.

DEPLOY ON UBUNTU VPS
1. Upload and extract this ZIP on your Ubuntu VPS. Example:
   unzip RushHours-Working-App.zip -d /root/rushhours-deploy
2. Run the deploy script, passing the domain already used by the website:
   cd /root/rushhours-deploy
   sudo PUBLIC_URL=https://app.rushhourscafe.in bash ./deploy-ec2.sh

The script builds the frontend and backend on the VPS. It may take several minutes and needs internet access for package/dependency downloads. It creates /etc/cafeqr/backend.env and generates database/JWT secrets if that file does not already exist. Payment features need valid Razorpay credentials to be configured there.

TLS WARNING
The included deploy script configures Nginx on HTTP port 80. If this domain already has HTTPS/Certbot configured, back up the current Nginx config and certificate setup before running it, because the script replaces the cafeqr Nginx site configuration. After deploying, verify HTTPS and re-enable/reissue the certificate if needed:
   sudo certbot --nginx -d app.rushhourscafe.in
Do not run Certbot until DNS points to this VPS and inbound ports 80 and 443 are allowed.

CHECK AFTER DEPLOYMENT
   sudo systemctl status cafeqr-backend --no-pager
   sudo journalctl -u cafeqr-backend -n 100 --no-pager
   sudo docker ps
   curl -i http://127.0.0.1/api/menu/categories
   curl -i https://app.rushhourscafe.in/api/menu/categories

The application is source/deployment-ready, but it has not been run against your VPS or its database from this environment. It cannot be truthfully described as verified live until these checks pass. Change the default development admin password immediately after first login.
